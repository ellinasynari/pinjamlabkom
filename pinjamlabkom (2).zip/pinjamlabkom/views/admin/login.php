
<h1>Login Admin</h1>
<form action="index.php?url=admin/do_login" method="POST">
    <label>Username</label><br>
    <input type="text" name="username" required><br>
    <label>Password</label><br>
    <input type="password" name="password" required><br>
    <button type="submit">Login</button>
</form>
